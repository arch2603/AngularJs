see https://github.com/lemonde/angular-ckeditor/releases
